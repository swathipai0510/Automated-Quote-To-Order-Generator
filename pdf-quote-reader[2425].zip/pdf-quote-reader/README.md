# PDF Quote Reader

This project is a Spring Boot application that reads quotes from PDF files and displays them on a webpage. It utilizes the Thymeleaf template engine for rendering HTML content.

## Features

- Reads PDF files containing quotes.
- Extracts quote information such as text and author.
- Displays the extracted quotes on a web page.

## Project Structure

```
pdf-quote-reader
├── src
│   ├── main
│   │   ├── java
│   │   │   └── com
│   │   │       └── example
│   │   │           └── pdfquotereader
│   │   │               ├── PdfQuoteReaderApplication.java
│   │   │               ├── controller
│   │   │               │   └── QuoteController.java
│   │   │               ├── service
│   │   │               │   └── PdfReaderService.java
│   │   │               └── model
│   │   │                   └── Quote.java
│   │   └── resources
│   │       ├── templates
│   │       │   └── quote.html
│   │       └── application.properties
│   └── test
│       └── java
│           └── com
│               └── example
│                   └── pdfquotereader
│                       └── PdfQuoteReaderApplicationTests.java
├── pom.xml
└── README.md
```

## Setup Instructions

1. Navigate to the project directory:
   ```
   cd pdf-quote-reader
   ```

2. Build the project using Maven:
   ```
   mvn clean install
   ``

3. Run the application:
   ```
   mvn spring-boot:run
   ```

4. Open your web browser and go to `http://localhost:8080/quote` to view the quotes.

## Usage

- Place your PDF quote files in the designated directory (to be specified in the application properties).
- Access the quotes through the web interface.

## Dependencies

This project uses the following dependencies:

- Spring Boot
- Thymeleaf
- PDF parsing library (e.g., Apache PDFBox)


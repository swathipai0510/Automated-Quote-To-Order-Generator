package com.example.pdfquotereader;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

@SpringBootApplication
public class PdfQuoteReaderApplication extends SpringBootServletInitializer{

    public static void main(String[] args) {
        SpringApplication.run(PdfQuoteReaderApplication.class, args);
    }
}
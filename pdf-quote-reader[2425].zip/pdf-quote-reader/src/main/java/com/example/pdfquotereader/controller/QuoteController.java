package com.example.pdfquotereader.controller;

import java.nio.file.Path;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.example.pdfquotereader.service.PdfReaderService;

@Controller
public class QuoteController {

    @Autowired
    private PdfReaderService pdfReaderService;

    @Autowired
        private ResourceLoader resourceLoader;

    @GetMapping("/quote")
    public String getQuote(Model model) {
        String quoteString;
        Resource resource = resourceLoader.getResource("classpath:test.pdf");
        
        try {
            quoteString = pdfReaderService.readPdfQuote(resource.getFile().toPath().toString());
            System.err.println("Quote: " + quoteString);
        } catch (java.io.IOException e) {
            // Handle the exception, e.g., log it and set a default message
            quoteString = "Error reading PDF: " + e.getMessage();
        }
        // If you have a way to convert String to Quote, do it here. Otherwise, pass the string directly.
        model.addAttribute("quotetext", quoteString);
        return "quote";
    }
}